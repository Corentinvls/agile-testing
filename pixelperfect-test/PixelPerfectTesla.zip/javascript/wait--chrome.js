var callback = arguments[arguments.length-1];
setTimeout(callback, 3000);
